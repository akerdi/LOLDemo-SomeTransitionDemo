//
//  LOLHeader.h
//  FaceBookPJ
//
//  Created by MyCompany on 16/12/17.
//  Copyright © 2016年 littleshuai. All rights reserved.
//

#ifndef LOLHeader_h
#define LOLHeader_h


#import "SHAttributeTool.h"
#import "SHAPIManager.h"

#define LOLToken @"58E40-4917D-4EDCE-7A4E4"

#define CellPadding 8

#endif /* LOLHeader_h */
