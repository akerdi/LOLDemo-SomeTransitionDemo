//
//  SHChampionDetailVC.m
//  FaceBookPJ
//
//  Created by MyCompany on 16/12/17.
//  Copyright © 2016年 littleshuai. All rights reserved.
//

#import "SHChampionDetailVC.h"
#import "SHImageGallaryVC.h"

#import "SHChampionsModel.h"
#import "SHChampionsDetailModel.h"

#import "SHChampionDetailTitleCellNode.h"
#import "SHAbilityCellNode.h"
#import "SHSkinsNode.h"

#import <MJExtension/MJExtension.h>

@interface SHChampionDetailVC ()<ASTableDelegate,ASTableDataSource>

@property (nonatomic, strong) ASDisplayNode *viewNode;
@property (nonatomic, strong) ASTableNode *tableNode;

@property (nonatomic, strong) SHChampionsModel *model;
@property (nonatomic, strong) SHChampionsDetailModel *detailModel;

@end

@implementation SHChampionDetailVC

-(instancetype)initWithChampionModel:(SHChampionsModel *)model{
    self.viewNode = [[ASDisplayNode alloc]init];
    self.viewNode.backgroundColor = [UIColor whiteColor];
    if (self = [super initWithNode:self.viewNode]) {
        self.model = model;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title = self.model.cname;
    
    self.tableNode = [[ASTableNode alloc]initWithStyle:UITableViewStyleGrouped];
    self.tableNode.delegate = self;
    self.tableNode.dataSource = self;
    [self.view addSubnode:self.tableNode];
//    self.tableNode.view.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableNode.style.flexGrow = 1;
    @weakify(self);
    self.node.layoutSpecBlock = ^ASLayoutSpec *(ASDisplayNode * _Nonnull node, ASSizeRange constrainedSize) {
        @strongify(self);
        return [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionVertical spacing:0 justifyContent:ASStackLayoutJustifyContentStart alignItems:ASStackLayoutAlignItemsCenter children:@[self.tableNode]];
    };
    [TSMessage showNotificationWithTitle:[NSString stringWithFormat:@"宇宙无敌超级好玩英雄:%@",self.title] type:TSMessageNotificationTypeMessage];
    [self fetchData];
}

-(NSInteger)tableNode:(ASTableNode *)tableNode numberOfRowsInSection:(NSInteger)section{
    /*
     info =             {
     attack = 8;
     defense = 6;
     difficulty = 3;
     magic = 3;
     };
     头像 name title
     头像 attack
     头像 defense
     头像 magic
     头像 difficulty
     
     image          spells:Q:image{full}       W:image{full}        E:image{full}       R:image{full}
     passive                 name
     description             tooltip
     
     
     
     
     
     */
    return self.detailModel?2+self.detailModel.skins.count:0;
}

-(void)tableNode:(ASTableNode *)tableNode willDisplayRowWithNode:(SHChampionDetailTitleCellNode *)node{
    if (self.detailModel&&node.indexPath.row==0) {
        [node.nodeArray enumerateObjectsUsingBlock:^(ASDisplayNode*  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            NSNumber *num = [self.detailModel.info valueForKeyPath:@[@"attack",@"defense",@"difficulty",@"magic"][idx]];
            CGFloat per = num.integerValue*1.0/10;
            POPSpringAnimation *springAnimation = [POPSpringAnimation animationWithPropertyNamed:kPOPShapeLayerStrokeEnd];
            springAnimation.springBounciness = 20;
            springAnimation.fromValue = @0;
            springAnimation.toValue = @(per);
            springAnimation.removedOnCompletion = NO;
            [obj.layer.sublayers[0] pop_addAnimation:springAnimation forKey:@"springPOP"];
        }];
    }
}

-(ASCellNodeBlock)tableNode:(ASTableNode *)tableNode nodeBlockForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row==0) {
        return ^{
            SHChampionDetailTitleCellNode *node = [[SHChampionDetailTitleCellNode alloc]initWithModel:self.model championsDetailModel:self.detailModel];
            return node;
        };
    }else if (indexPath.row==1){
        return ^{
            SHAbilityCellNode *node = [[SHAbilityCellNode alloc]initWithMode:self.detailModel];
            return node;
        };
    }else{
        SHChampionsDetailSkins *skinModel = self.detailModel.skins[indexPath.row-2];
        return ^{
            SHSkinsNode *node = [[SHSkinsNode alloc]initWithModel:skinModel];
            return node;
        };
    }
}

-(void)tableNode:(ASTableNode *)tableNode didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableNode deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.row>1) {
        SHChampionsDetailSkins *skinModel = self.detailModel.skins[indexPath.row-2];
        LxDBAnyVar(skinModel);
        LxDBAnyVar(@"点击进去，可以查看大图，操作大图，保存大图");
        SHImageGallaryVC *vc = [[SHImageGallaryVC alloc]initWithModel:@{@"champion_id":self.model.id,@"skinid":skinModel.id}];
        [self.navigationController pushViewController:vc animated:YES];
    }
}
-(void)fetchData{
    [[SHAPIManager sharedManager] getChampionDetailWithParametor:@{@"champion_id":self.model.id} progress:^(NSProgress * _Nonnull progress) {
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
         self.detailModel = [SHChampionsDetailModel mj_objectWithKeyValues:responseObject[@"data"][0]];
         [self.tableNode reloadData];
        LxDBAnyVar(responseObject);
    } fail:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        LxDBAnyVar(error);
    }];
}

@end
