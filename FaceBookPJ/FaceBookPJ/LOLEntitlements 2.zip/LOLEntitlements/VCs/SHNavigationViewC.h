//
//  SHNavigationViewC.h
//  FaceBookPJ
//
//  Created by MyCompany on 16/12/25.
//  Copyright © 2016年 littleshuai. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SHNavigationViewC : UINavigationController<UINavigationControllerDelegate,UIViewControllerTransitioningDelegate>

@end
