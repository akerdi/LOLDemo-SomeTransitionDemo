//
//  SHChampionsModel.m
//  FaceBookPJ
//
//  Created by MyCompany on 16/12/17.
//  Copyright © 2016年 littleshuai. All rights reserved.
//

#import "SHChampionsModel.h"

@implementation SHChampionsModel

@end
