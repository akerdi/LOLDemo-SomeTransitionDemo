//
//  SHChampionDetailCellNode.m
//  FaceBookPJ
//
//  Created by MyCompany on 16/12/18.
//  Copyright © 2016年 littleshuai. All rights reserved.
//

#import "SHChampionDetailTitleCellNode.h"

#import "SHChampionsModel.h"
#import "SHChampionsDetailModel.h"

@interface SHChampionDetailTitleCellNode ()

@property (nonatomic, strong) ASImageNode *portImgNode;
@property (nonatomic, strong) ASTextNode *textNode;
//@property (nonatomic, strong) ASDisplayNode *separatorNode;

@property (nonatomic, strong) SHChampionsModel *championsModel;
@property (nonatomic, strong) SHChampionsDetailModel *championsDetailModel;

@end

@implementation SHChampionDetailTitleCellNode

-(instancetype)initWithModel:(id)championsModel championsDetailModel:(id)championsDetailModel{
    if (self = [super init]) {
        
        self.championsModel = championsModel;
        self.championsDetailModel = championsDetailModel;
        
        self.portImgNode = [[ASImageNode alloc]init];
        self.portImgNode.image = [UIImage imageWithContentsOfFile:[[NSBundle mainBundle] pathForResource:self.championsModel.pic ofType:nil]];
        [self addSubnode:self.portImgNode];
        self.textNode = [[ASTextNode alloc]init];
        self.textNode.style.flexGrow = 1;
        self.textNode.layerBacked = YES;
        self.textNode.attributedText = [[NSAttributedString alloc]initWithString:[NSString stringWithFormat:@"%@ %@",self.championsDetailModel.name,self.championsDetailModel.title]];
        
        [self addSubnode:self.textNode];
        self.shapeArray = [[NSMutableArray alloc]initWithCapacity:4];
        self.nodeArray = [[NSMutableArray alloc]initWithCapacity:4];
        for (int i=0; i<4; i++) {
            CAShapeLayer *layer = [CAShapeLayer layer];
            layer.lineWidth = 4;
//            UIBezierPath *path = [UIBezierPath bezierPathWithRect:CGRectMake(0, 0, 100, 8)];
            UIBezierPath *path = [UIBezierPath bezierPath];
            [path moveToPoint:CGPointMake(0, 0)];
            [path addLineToPoint:CGPointMake(100, 0)];
            layer.path = path.CGPath;
            layer.fillColor = nil;
            layer.strokeColor = [UIColor randomFlatColor].CGColor;
            layer.lineCap = kCALineCapRound;
            layer.lineJoin = kCALineJoinRound;
            layer.strokeEnd = 0;
            ASDisplayNode *node = [[ASDisplayNode alloc]init];
            node.style.preferredSize = CGSizeMake(100, 10);
            node.style.flexGrow = YES;
            [self addSubnode:node];
            [self.nodeArray addObject:node];
            [self.shapeArray addObject:layer];
        }
        
//        self.separatorNode = [[ASDisplayNode alloc]init];
//        self.separatorNode.backgroundColor = [UIColor flatGrayColor];
//        [self addSubnode:self.separatorNode];
        
    }
    return self;
}

-(void)displayWillStart{
    [super displayWillStart];
}

-(void)didLoad{
    [super didLoad];
    [self.nodeArray enumerateObjectsUsingBlock:^(ASTextNode*  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        [obj.layer addSublayer:self.shapeArray[idx]];
    }];
    
//    CGSize size = self.calculatedSize;
//    self.separatorNode.frame = CGRectMake(CellPadding, size.height-1, size.width-CellPadding, 1/[UIScreen mainScreen].scale);
    
}

-(ASLayoutSpec *)layoutSpecThatFits:(ASSizeRange)constrainedSize{
    
    self.portImgNode.style.preferredSize = CGSizeMake(80, 80);
//    self.textNode.style.preferredSize = CGSizeMake(constrainedSize.max.width-2*CellPadding-80-CellPadding, 20);
    NSMutableArray *arr = [[NSMutableArray alloc]initWithArray:self.nodeArray];
    [arr insertObject:self.textNode atIndex:0];
    ASStackLayoutSpec *verticalSpec = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionVertical spacing:3 justifyContent:ASStackLayoutJustifyContentStart alignItems:ASStackLayoutAlignItemsStart children:arr];
    verticalSpec.style.flexGrow = 1;
    self.textNode.style.spacingAfter = 8;
    self.textNode.style.spacingBefore = 8;
    
    ASStackLayoutSpec *horizenSpec = [ASStackLayoutSpec stackLayoutSpecWithDirection:ASStackLayoutDirectionHorizontal spacing:CellPadding justifyContent:ASStackLayoutJustifyContentStart alignItems:ASStackLayoutAlignItemsCenter children:@[self.portImgNode,verticalSpec]];
    
    return [ASInsetLayoutSpec insetLayoutSpecWithInsets:UIEdgeInsetsMake(8, 8, 8, 8) child:horizenSpec];
}


@end
