//
//  SHImageGallaryVC.h
//  FaceBookPJ
//
//  Created by MyCompany on 16/12/21.
//  Copyright © 2016年 littleshuai. All rights reserved.
//

#import <AsyncDisplayKit/AsyncDisplayKit.h>

@interface SHImageGallaryVC : ASViewController

-(instancetype)initWithModel:(id)model;

@end
