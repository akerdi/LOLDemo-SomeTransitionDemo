//
//  LOLHeader.h
//  FaceBookPJ
//
//  Created by MyCompany on 16/12/17.
//  Copyright © 2016年 littleshuai. All rights reserved.
//

#ifndef LOLHeader_h
#define LOLHeader_h


#import "SHAttributeTool.h"
#import "SHAPIManager.h"

#define LOLToken @"2C111-2C74D-B147E-AAA74"

#define CellPadding 8

#endif /* LOLHeader_h */
