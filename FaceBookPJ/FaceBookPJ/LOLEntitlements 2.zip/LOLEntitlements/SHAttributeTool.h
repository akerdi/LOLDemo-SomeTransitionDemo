//
//  SHAttributeTool.h
//  FaceBookPJ
//
//  Created by MyCompany on 16/12/17.
//  Copyright © 2016年 littleshuai. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHAttributeTool : NSObject

+(NSAttributedString *)championtitleAttributeWith:(NSString *)str;
+(NSAttributedString *)championDetailDescriptionWith:(NSString *)str;
+(NSAttributedString *)championDetailTitleWith:(NSString *)str;

@end
